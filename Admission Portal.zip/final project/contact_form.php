<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Include PHPMailer autoload file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST["name"];
    $phonno = $_POST["phone"];
    $email = $_POST["email"];
    $city = $_POST["city"];

    // Create a PHPMailer instance
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'ra7030725@gmail.com'; // Your SMTP username
        $mail->Password = 'ytgy qasy czwn ueqm'; // Your SMTP password
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;

        // Recipients
        $mail->setFrom('ra7030725@gmail.com', 'riaz'); // Sender's email and name
        $mail->addAddress('riazalam029@gmail.com', 'Recipient Name'); // Recipient's email and name

        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'New Form Submission';
        $mail->Body = "Name: $name<br>Phone Number: $phonno<br>Email: $email<br>City: $city";

        // Send email
        $mail->send();
        echo 'Thanks for contact us we will be response you as soon as possible ...plz wait for our response ';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
