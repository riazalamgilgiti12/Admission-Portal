CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    whatsapp VARCHAR(15) NOT NULL,
    dob DATE NOT NULL,
    gender ENUM('Male', 'Female') NOT NULL,
    fee_submission_date DATE NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    course VARCHAR(50) NOT NULL,
    challan_copy VARCHAR(255) NOT NULL
);
