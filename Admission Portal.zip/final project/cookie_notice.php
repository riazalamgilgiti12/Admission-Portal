<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cookies Notice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            text-align: center;
            margin: 0;
            padding: 50px;
        }

        .cookie-notice {
            background-color: #fff;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="cookie-notice">
        <h1>Cookies Notice</h1>
        <p>This website uses cookies to enhance user experience.</p>
        <button onclick="acceptCookies()">Accept</button>
        <button onclick="rejectCookies()">Not Accept</button>
    </div>

    <script>
        function acceptCookies() {
            // Set a cookie to remember user's choice
            document.cookie = "accept_cookies=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/";
            window.location.href = "index.php"; // Redirect to the main page after accepting cookies
        }

        function rejectCookies() {
            // Redirect to a page informing the user that cookies are required to access the website
            window.location.href = "cookies_required.php";
        }
    </script>
</body>
</html>
