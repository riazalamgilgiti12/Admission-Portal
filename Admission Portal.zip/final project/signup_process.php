



<?php
$server = "localhost";
$username = "root";
$password = "";
$db = "students";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establish database connection
    $conn = new mysqli($server, $username, $password, $db);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get form data
    $name = isset($_POST["name"]) ? $_POST["name"] : '';
    $email = isset($_POST["email"]) ? $_POST["email"] : '';
    $phone = isset($_POST["phone"]) ? $_POST["phone"] : '';
    $whatsapp = isset($_POST["whatsapp"]) ? $_POST["whatsapp"] : '';
    $dob = isset($_POST["dob"]) ? $_POST["dob"] : '';
    $gender = isset($_POST["gender"]) ? $_POST["gender"] : '';
    $fee_submission_date = isset($_POST["fee_submission_date"]) ? $_POST["fee_submission_date"] : '';
    $amount = isset($_POST["amount"]) ? $_POST["amount"] : '';
    $course = isset($_POST["course"]) ? $_POST["course"] : '';

    // File upload handling
    $target_dir = "uploads/";
    $challan_copy = isset($_FILES["challan_copy"]["name"]) ? $target_dir . basename($_FILES["challan_copy"]["name"]) : '';

    if (isset($_FILES["challan_copy"]["tmp_name"]) && !empty($_FILES["challan_copy"]["tmp_name"])) {
        if (move_uploaded_file($_FILES["challan_copy"]["tmp_name"], $challan_copy)) {
            echo "File uploaded successfully.";
        } else {
            echo "Error uploading file.";
        }
    } else {
        echo "No file uploaded.";
    }

    // Insert data into the database
    $checkSql = "SELECT * FROM students WHERE email='$email' AND course='$course'";
    $checkResult = $conn->query($checkSql);

    if ($checkResult->num_rows > 0) {
        echo "You are already enrolled in this course with the provided email.";
    } else {
        $sql = "INSERT INTO students (name, email, phone, whatsapp, dob, gender, fee_submission_date, amount, course, challan_copy)
                VALUES ('$name', '$email', '$phone', '$whatsapp', '$dob', '$gender', '$fee_submission_date', '$amount', '$course', '$challan_copy')";

        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    // Select and display records from the database
    $sql = "SELECT * FROM students";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<h2>All Records:</h2>";
        echo "<table border='1'>";
        echo "<tr><th>Name</th><th>Email</th><th>Phone</th><th>whatsapp</th><th>dob</th><th>gender</th><th>fee_submission_date</th><th>amount</th><th>course</th><th>Actions</th></tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["email"] . "</td>";
            echo "<td>" . $row["phone"] . "</td>";
            echo "<td>" . $row["whatsapp"] . "</td>";
            echo "<td>" . $row["dob"] . "</td>";
            echo "<td>" . $row["gender"] . "</td>";
            echo "<td>" . $row["fee_submission_date"] . "</td>";
            echo "<td>" . $row["amount"] . "</td>";
            echo "<td>" . $row["course"] . "</td>";

            echo "<td>";
            echo '<form action="" method="post">';
            echo '<input type="hidden" name="email" value="' . $row["email"] . '">';
            echo '<input type="submit" name="update" value="Update">';
            echo '<input type="submit" name="delete" value="Delete">';
            echo '</form>';
            echo "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No records found in the database.";
    }
}

// Handle form submission for updating data
if (isset($_POST["update"])) {
    // Get email from form data
    $email = isset($_POST["email"]) ? $_POST["email"] : '';

    // Fetch existing data based on email and populate the form fields
    $sql = "SELECT * FROM students WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Display form with existing data
        echo '<form action="" method="post">';
        echo 'Name: <input type="text" name="name" value="' . $row["name"] . '"><br>';
        echo 'Email: <input type="email" name="email" value="' . $row["email"] . '"><br>';
        echo 'Phone: <input type="tel" name="phone" value="' . $row["phone"] . '"><br>';
        echo 'whatsapp: <input type="number" name="whatsapp" value="' . $row["whatsapp"] . '"><br>';
        echo 'dob: <input type="date" name="dob" value="' . $row["dob"] . '"><br>';
        echo 'Gender: <input type="radio" name="gender" value="male" ' . ($row["gender"] == "male" ? 'checked' : '') . '> Male ';
        echo '<input type="radio" name="gender" value="female" ' . ($row["gender"] == "female" ? 'checked' : '') . '> Female <br>';
        echo 'fee_submission_date: <input type="date" name="fee_submission_date" value="' . $row["fee_submission_date"] . '"><br>';
        echo 'amount: <input type="number" name="amount" value="' . $row["amount"] . '"><br>';
        echo 'course: <input type="text" name="course" value="' . $row["course"] . '"><br>';
        echo '<input type="submit" name="updateData" value="Update Data">';
        echo '</form>';
    } else {
        echo "No data found for the given email.";
    }
}

// Handle form submission for updating data
if (isset($_POST["updateData"])) {
    // Retrieve updated form data
    $name = isset($_POST["name"]) ? $_POST["name"] : '';
    $email = isset($_POST["email"]) ? $_POST["email"] : '';
    $phone = isset($_POST["phone"]) ? $_POST["phone"] : '';
    $whatsapp = isset($_POST["whatsapp"]) ? $_POST["whatsapp"] : '';
    $dob = isset($_POST["dob"]) ? $_POST["dob"] : '';
    $gender = isset($_POST["gender"]) ? $_POST["gender"] : '';
    $fee_submission_date = isset($_POST["fee_submission_date"]) ? $_POST["fee_submission_date"] : '';
    $amount = isset($_POST["amount"]) ? $_POST["amount"] : '';
    $course = isset($_POST["course"]) ? $_POST["course"] : '';

    // Update data in the database
    $updateSql = "UPDATE students SET name='$name', phone='$phone', whatsapp='$whatsapp', dob='$dob', gender='$gender', fee_submission_date='$fee_submission_date', amount='$amount', course='$course' WHERE email='$email'";

    if ($conn->query($updateSql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Handle form submission for deleting data
if (isset($_POST["delete"])) {
    // Get email from form data
    $email = isset($_POST["email"]) ? $_POST["email"] : '';

    // Delete specific row based on email
    $sql = "DELETE FROM students WHERE email='$email'";

    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
