<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Document</title>
    <style>
      .cookie-popup {
      display: none;
      position: fixed;
      bottom: 20px;
      left: 20px;
      background-color: #333;
      color: #fff;
      padding: 15px;
      border-radius: 10px;
    }
    .image2 {
      height: 500px;
    }

    </style>
    
    
    <!-- <style>
      /* styles.css */
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  background-color: #e0abab;
}
.img1{
  height: 150px;
}

header {
  background-color: #007bff;
  color: #fff;
  text-align: center;
  padding: 20px;
}

main {
  max-width: 800px;
  margin: 20px auto;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
}

h2 {
  color: #007bff;
}

footer {
  text-align: center;
  padding: 10px;
  background-color: #007bff;
  color: #fff;
}

    </style> -->
   
    <link rel="stylesheet" href="external.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
</head>
<body>
  <?php
  if (!isset($_COOKIE['accept_cookies']) || $_COOKIE['accept_cookies'] !== 'true') {
    // User has not accepted cookies, show a message or redirect to a different page
    header('Location: cookie_notice.php'); // Redirect to a cookie notice page
    exit(); // Stop further execution of the script
}
?>
    
    <header>
        <h1 class="nav ">Admission Guidance Portal</h1>
         
          <img src="img/Untitled_logo_5_free-file.jpg">
        
      </header>
      
      
    <nav>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="admission.html">Admission Process</a></li>
        <li><a href="course.html">Courses</a></li>
        <li><a href="scholarship.php">Scholarships</a></li>
        <li><a href="Contact.html">Contact</a></li>
      </ul>
     
      
    </nav>
    
    <br><br>
   
    
  </div>
</div>
<div class="container">
  <div class="row">

  <h1 style="text-align: center;">Upcomming schalorships</h1>
  <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img\SCHoloHD1.jpg" class=" image2 d-block w-100 h-500" alt="...">
      <div class="carousel-caption d-none d-md-block">
        
      </div>
    </div>
    <div class="carousel-item">
      <img src="img\schorHD4.jpeg" class=" image2  d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        
      </div>
    </div>
    <div class="carousel-item">
      <img src="img\scholarshipHD3.jpg"  class="image2  d-block w-100 " alt="...">
      <div class="carousel-caption d-none d-md-block">
       
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>
</div>
  <!-- <div><img src="img\schor3.jpg" style="height: 800px;width: 50%;" alt="">
<img src="img\schol2.jpg" style="height: 800px;width: -50%;margin-left:40px" alt=""></div> -->
</div>
  <div class="container-fluid">
    <div class="row">
      <div class="col-xl-6 col-sm-12">
      <h2>Empowering Excellence: Scholarships for <span class="text-info">High-Achieving Students</span>

      </h2>
      <p class = "">At BMPS, we believe in the power of education to transform lives, and we are committed to nurturing the potential of our future leaders. With this commitment in mind, we are proud to announce our scholarship program tailored for students whose academic excellence knows no bounds. Under the banner of "Empowering Excellence," our organization is delighted to offer scholarships to students who have achieved outstanding marks of 70% or higher.

        We firmly believe that exceptional dedication and hard work should be celebrated and rewarded. These scholarships are not just a testament to the students' diligence but also a stepping stone towards their aspirations. Our aim is to provide financial support and encouragement to these high-achieving individuals, enabling them to pursue their dreams in higher education without the added burden of excessive financial stress.</p>
      </div>
    <div class="col-xl-6 col-sm-12 text-center">
      <main>
        <section class="scholarship-info">
            <h2>Scholarship Opportunities</h2>
            <p>Discover our scholarship programs designed to help you achieve your educational goals.</p>
        </section>
        <section class="eligibility">
            <h3 class="text-success ">Eligibility Criteria</h3>
            <ul>
                <li style="list-style: none;">Minimum marks 70% in your last certificate</li>
                
               
            </ul>
        </section>
        <section class="application-process">
            <h3 class="text-success">Application Process</h3>
            <ol>
                <li style="list-style: none;">Complete the online application form.</li>
                <li style="list-style: none;">Submit your academic transcripts.</li>
                <li style="list-style: none;">Last date : 25-11-2023.</li>
                <h2>How to apply</h2>
                <p>please fill form blow the given website</p>
                <ul style="color: red">www.bmps.com</ul>
                <!-- Add more application steps -->
            </ol>
        </section>
    </div>
    
  </div>
  <div class="cookie-popup" id="cookiePopup">
        This website uses cookies to enhance user experience.
        <button onclick="acceptCookies()">Accept Cookies</button>
    </div>
    
    <script>
        // Check if cookies are already accepted
        window.onload = function () {
            var cookiesAccepted = <?php echo isset($_COOKIE['accept_cookies']) ? 'true' : 'false'; ?>;
            console.log('Cookies Accepted: ' + cookiesAccepted); // Log the value of cookiesAccepted
            if (!cookiesAccepted) {
                document.getElementById('cookiePopup').style.display = 'block';
            }
        };
    
        function acceptCookies() {
            // Set a cookie to remember user's choice
            document.cookie = "accept_cookies=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/";
            console.log('Cookies Accepted: true'); // Log that cookies were accepted
            document.getElementById('cookiePopup').style.display = 'none';
        }
    </script>
    
      
     
  </main>
  
            
                
    </div>

  </div>
</div>
<div class="container">
  <div class="row">
    
  </div>
</div>

<footer>
  <p>&copy; 2023 Admission Guidance Portal. All rights reserved.</p>
</footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>