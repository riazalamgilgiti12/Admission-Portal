<!DOCTYPE html>
<html>
<head>
  <title>Admission Guidance Portal</title>
  <link rel="stylesheet" href="external.css">
  <style>
    /* CSS styles */
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }
    h2{
    text-align:center;
    background-color:#f5f5f5
    }
    header {
      background-color: #333;
      color: #fff;
      padding: 20px;
      text-align: center;
    }
    
    h1 {
      margin: 0;
    }
    
    nav {
      background-color: #f5f5f5;
      padding: 10px;
      text-align: center;
    }
    .nav{
      color:red;
      background-color:white;
      margin:auto;
      width:50%
    
    }
    
    nav ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
    }
    
    
    nav ul li {
      display: inline-block;
      margin: 0 10px;
    }
    
    nav ul li a {
      text-decoration: none;
      color: #333;
      padding: 5px 10px;
    }
    header img{
      width: 5%;
      border-radius: 10px;
      background-color: 30px solid yellow;
      position: absolute;
      left: 0px;
      top:0px;
      margin:top;
      border:8px;
       
      display: inline block;
      
      background-repeat: none;
      
      
  }
    
           
    
    .container {
      max-width: 960px;
      margin: 20px auto;
      padding: 0 20px;
    }
    
    .content {
      background-color: #f5f5f5;
      padding: 20px;
    }
    
    footer {
      background-color: #333;
      color: #fff;
      padding: 20px;
      text-align: center;
      margin-top: 30px;
    }
    #client-section{
      height: 500px;
      position: relative;
      background-color: aquamarine;
      
      
      

  }
  #client-section::before{
      content: "";
      position: absolute;
      background: url('../4.webp')no-repeat center center/cover;
      width: 100%;
      height: 100%;
      z-index: -1;
      opacity: 0.5;

  }
  


 
 
  
  .secondary center{
      font-size: 2rem;
  }
 
.secondary center{
    font-size: 2rem;
}
.center{
  text-align: center;
}
.services-container h1{
  text-align: center;
}
.item1 img{
  margin-left: 590px;
  width: 350px;
  height: 400px;
  margin-top: 0px;
  margin-bottom: 100px;
  position: absolute;
  display: inline;
}
.item2 img{
  position: absolute;
  margin-left: 50px;
  width: 350px;
  height: 400px;
  display: inline;
  

}
.item3 img{
  margin-left: 1090px;
  width: 350px;
  height: 400px;
  margin-top: 0px;
  margin-bottom: 100px;
  position: absolute;
  display: inline;
}
.img3{
  color: red;
}
.cookie-popup {
      display: none;
      position: fixed;
      bottom: 20px;
      left: 20px;
      background-color: #333;
      color: #fff;
      padding: 15px;
      border-radius: 10px;
    }


        
        
        


  </style>
</head>
<body>
<?php

 if (!isset($_COOKIE['accept_cookies']) || $_COOKIE['accept_cookies'] !== 'true') {
    // User has not accepted cookies, show a message or redirect to a different page
    header('Location: cookie_notice.php'); // Redirect to a cookie notice page
     exit(); // Stop further 
 }
 ?>

  <header>
    <h1 class="nav">Admission Guidance Portal</h1>
     
      <img src="img\Untitled_logo_5_free-file.jpg">
    
  </header>
  
  <nav>
    <ul>
      <li class="al"><a href="home.html">Home</a></li>
      <li class="al"><a href="admission.html">Admission Process</a></li>
      <li class="al"><a href="course.html">Courses</a></li>
      <li class="al"><a href="scholarship.php">Scholarships</a></li>
      <li class="al"><a href="Contact.html">Contact</a></li>
    </ul>
   
    
  </nav>
  
  
  <div class="container">
    <div class="content">
      <h2>Welcome to our Admission Guidance Portal</h2>
      
      <p>
        An admission guidance portal for students is a comprehensive platform designed
         to assist and support individuals in their pursuit of higher education. This online
          tool acts as a reliable resource and a guiding light for students who are navigating
           the complex process of college and university admissions.
      </p>
      <p>
        Additionally, the portal often offers valuable resources such as sample essays, 
        interview tips, and guidance on writing effective resumes and recommendation letters.
         These resources empower students to present themselves in the best possible light during 
         the application process,increasing their chances of securing admission to their desired institutions.
      </p>
    </div>
  </div>
  <div> 
    <h2 class="img">Some Images our school</h2>
  </div>
    <section id="client-section">
     
      <div id="clients">
        <div class="item1">
          
          <img src="img/all corse.jpg " alt="image 1">
        </div>
        <div class="item2">
          
          <img src="img/home.jpg" alt="">
        </div>
        <div class="item3">
          
          
          <img src="contact.jpg" alt="">
          
        </div>

          
      </div>
       <div class="cookie-popup" id="cookiePopup">
        This website uses cookies to enhance user experience.
        <button onclick="acceptCookies()">Accept Cookies</button>
    </div>
    
    <script>
        // Check if cookies are already accepted
         window.onload = function () {
             var cookiesAccepted = <?php echo isset($_COOKIE['accept_cookies']) ? 'true' : 'false'; ?>;
            console.log('Cookies Accepted: ' + cookiesAccepted); // Log the value of cookiesAccepted
            if (!cookiesAccepted) {
                 document.getElementById('cookiePopup').style.display = 'block';
             }
         };
    
         function acceptCookies() {
            //  Set a cookie to remember user's choice
           document.cookie = "accept_cookies=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/";
             console.log('Cookies Accepted: true'); // Log that cookies were accepted
             document.getElementById('cookiePopup').style.display = 'none';
         }
     </script>
    
  </section>
    
  





  
  <footer>
    <p>&copy; 2023 Admission Guidance Portal. All rights reserved.</p>
  </footer>
</body>
</html>
